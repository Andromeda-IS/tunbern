﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour {

    public GameObject Player;

    public GameObject SpawnPoint;

    public Vector3 offset;

    public Vector3 spawnpoint = SpawnPoint.transform.position;

	// Use this for initialization
	void Start () {
        offset.x = transform.position.x - Player.transform.position.x;
        Player.transform.position = spawnpoint;
    }
	
	// Update is called once per frame
	void LateUpdate () {
        transform.position = new Vector3(offset.x + Player.transform.position.x, offset.y, offset.z);
        if(Player.transform.position.y < -10f)
        {
            Player.transform.position = spawnpoint;
        }
	}
}
