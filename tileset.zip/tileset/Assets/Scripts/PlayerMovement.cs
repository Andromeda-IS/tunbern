﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	public CharacterController2D controller;
    public Animator animator;

	float horizontalMove = 0f;

	public float runspeed = 40f;
	bool jump = false;
	
	void Update ()
	{
        //checks controls
        horizontalMove = Input.GetAxisRaw("Horizontal") * runspeed;

        animator.SetFloat("Speed", Mathf.Abs(horizontalMove));

		if (Input.GetButtonDown("Jump"))
		{
			jump = true;
            Debug.Log("jump");
            animator.SetBool("Jump", true);
		}
        //move character
        controller.Move(horizontalMove * Time.deltaTime, false, jump);
        jump = false;

    }

    public void OnLanding()
    {
        animator.SetBool("Jump", false);
    }

}
