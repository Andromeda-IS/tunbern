﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	public CharacterController2D controller;

	float horizontalMove = 0f;

	public float runspeed = 40f;
	bool jump = false;
	
	void Update ()
	{
        //checks controls
        horizontalMove = Input.GetAxisRaw("Horizontal") * runspeed;

		if (Input.GetButtonDown("Jump"))
		{
			jump = true;
		}
        //move character
        controller.Move(horizontalMove * Time.deltaTime, false, jump);
        jump = false;
    }

}
